package edu.citytech.cst.s23370098.abcCounter;

import edu.citytech.cst.s23370098.service.ABCCounterService;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.FlowPane;

import java.util.List;

public class ABCCounterController {

    @FXML
    private FlowPane fpCounter;

    @FXML
    private Label title;

    @FXML
    private RadioButton rABC;

    @FXML
    private ToggleGroup tgCounter;

    @FXML
    private RadioButton r123;

    @FXML
    private RadioButton rNone;

    @FXML
    void mode(ActionEvent event) {
        fpCounter.getChildren().clear();
        List<Character> list = ABCCounterService.countABC();

        for(char abc : list) {
            var label = new Label(abc + "");
            fpCounter.getChildren().add(label);
        }
    }

}
